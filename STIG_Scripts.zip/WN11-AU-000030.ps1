<#
.SYNOPSIS
    This PowerShell script configures the system to audit Security Group Management successes.

.NOTES
    Author          : Michael Bowling Jr
    LinkedIn        : linkedin.com/in/michael-bowling-jr-17mbj/
    GitHub          : github.com/17mbj
    Date Created    : 2026-09-26
    Last Modified   : 2026-09-26
    Version         : 1.0
    CVEs            : N/A
    Plugin IDs      : N/A
    STIG-ID         : WN11-AU-000030
    Documentation   : https://stigaview.com/products/win11/v2r7/WN11-AU-000030/

.TESTED ON
    Date(s) Tested  : 2026-09-26
    Tested By       : Michael Bowling Jr
    Systems Tested  : Microsoft Windows 11 (Azure VM)
    PowerShell Ver. : 5.1

.USAGE
    Run as Administrator on a Windows 11 system:
    PS C:\> .\WN11-AU-000030.ps1
#>

# STIG Remediation: Audit Security Group Management - Success
# Uses AuditPol command to configure advanced audit policy

# Enable Success auditing for Security Group Management
auditpol /set /subcategory:"Security Group Management" /success:enable

# Verify
$auditResult = auditpol /get /subcategory:"Security Group Management"
if ($auditResult -match "Success") {
    Write-Host "[PASS] WN11-AU-000030: Security Group Management success auditing is enabled." -ForegroundColor Green
} else {
    Write-Host "[FAIL] WN11-AU-000030: Security Group Management success auditing is NOT enabled." -ForegroundColor Red
}
Write-Host "`nCurrent audit policy:" -ForegroundColor Cyan
$auditResult | ForEach-Object { Write-Host $_ }
