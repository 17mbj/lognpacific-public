<#
.SYNOPSIS
    This PowerShell script disables the convenience PIN sign-in for domain users on Windows 11.

.NOTES
    Author          : Michael Bowling Jr
    LinkedIn        : linkedin.com/in/michael-bowling-jr-17mbj/
    GitHub          : github.com/17mbj
    Date Created    : 2026-09-26
    Last Modified   : 2026-09-26
    Version         : 1.0
    CVEs            : N/A
    Plugin IDs      : N/A
    STIG-ID         : WN11-CC-000370
    Documentation   : https://stigaview.com/products/win11/v2r7/WN11-CC-000370/

.TESTED ON
    Date(s) Tested  : 2026-09-26
    Tested By       : Michael Bowling Jr
    Systems Tested  : Microsoft Windows 11 (Azure VM)
    PowerShell Ver. : 5.1

.USAGE
    Run as Administrator on a Windows 11 system:
    PS C:\> .\WN11-CC-000370.ps1
#>

# STIG Remediation: Disable convenience PIN sign-in
# Registry Path: HKLM\Software\Policies\Microsoft\Windows\System
# Value Name: AllowDomainPINLogon | Value Type: REG_DWORD | Value: 0

$regPath = "HKLM:\Software\Policies\Microsoft\Windows\System"

if (-not (Test-Path $regPath)) {
    New-Item -Path $regPath -Force | Out-Null
}

Set-ItemProperty -Path $regPath -Name "AllowDomainPINLogon" -Value 0 -Type DWord

# Verify
$currentValue = (Get-ItemProperty -Path $regPath -Name "AllowDomainPINLogon").AllowDomainPINLogon
if ($currentValue -eq 0) {
    Write-Host "[PASS] WN11-CC-000370: Convenience PIN sign-in is disabled." -ForegroundColor Green
} else {
    Write-Host "[FAIL] WN11-CC-000370: Convenience PIN sign-in is NOT disabled." -ForegroundColor Red
}
