<#
.SYNOPSIS
    This PowerShell script disables Internet Explorer 11 as a standalone browser on Windows 11.

.NOTES
    Author          : Michael Bowling Jr
    LinkedIn        : linkedin.com/in/michael-bowling-jr-17mbj/
    GitHub          : github.com/17mbj
    Date Created    : 2026-09-26
    Last Modified   : 2026-09-26
    Version         : 1.0
    CVEs            : N/A
    Plugin IDs      : N/A
    STIG-ID         : WN11-CC-000391
    Documentation   : https://stigaview.com/products/win11/v2r7/WN11-CC-000391/

.TESTED ON
    Date(s) Tested  : 2026-09-26
    Tested By       : Michael Bowling Jr
    Systems Tested  : Microsoft Windows 11 (Azure VM)
    PowerShell Ver. : 5.1

.USAGE
    Run as Administrator on a Windows 11 system:
    PS C:\> .\WN11-CC-000391.ps1
#>

# STIG Remediation: Disable Internet Explorer 11 as a standalone browser
# Registry Path: HKLM\SOFTWARE\Policies\Microsoft\Internet Explorer\Main
# Value Name: NotifyDisableIEOptions | Value Type: REG_DWORD | Value: 2
# (0 = Always, 1 = Once per user, 2 = Never)

$regPath = "HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main"

if (-not (Test-Path $regPath)) {
    New-Item -Path $regPath -Force | Out-Null
}

Set-ItemProperty -Path $regPath -Name "NotifyDisableIEOptions" -Value 2 -Type DWord

# Also disable IE11 via the DISM optional feature if present
try {
    $ieFeature = Get-WindowsOptionalFeature -Online -FeatureName "Internet-Explorer-Optional-amd64" -ErrorAction SilentlyContinue
    if ($ieFeature -and $ieFeature.State -eq "Enabled") {
        Disable-WindowsOptionalFeature -Online -FeatureName "Internet-Explorer-Optional-amd64" -NoRestart -ErrorAction SilentlyContinue
        Write-Host "[INFO] WN11-CC-000391: IE11 optional feature has been disabled (restart may be required)." -ForegroundColor Yellow
    }
} catch {
    Write-Host "[INFO] WN11-CC-000391: IE11 optional feature not found (expected on Windows 11)." -ForegroundColor Yellow
}

# Verify registry setting
$currentValue = (Get-ItemProperty -Path $regPath -Name "NotifyDisableIEOptions").NotifyDisableIEOptions
if ($currentValue -eq 2) {
    Write-Host "[PASS] WN11-CC-000391: Internet Explorer 11 is disabled as a standalone browser." -ForegroundColor Green
} else {
    Write-Host "[FAIL] WN11-CC-000391: Internet Explorer 11 is NOT properly disabled." -ForegroundColor Red
}
