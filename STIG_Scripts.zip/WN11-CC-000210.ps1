<#
.SYNOPSIS
    This PowerShell script enables Microsoft Defender SmartScreen for Explorer on Windows 11.

.NOTES
    Author          : Michael Bowling Jr
    LinkedIn        : linkedin.com/in/michael-bowling-jr-17mbj/
    GitHub          : github.com/17mbj
    Date Created    : 2026-09-26
    Last Modified   : 2026-09-26
    Version         : 1.0
    CVEs            : N/A
    Plugin IDs      : N/A
    STIG-ID         : WN11-CC-000210
    Documentation   : https://stigaview.com/products/win11/v2r7/WN11-CC-000210/

.TESTED ON
    Date(s) Tested  : 2026-09-26
    Tested By       : Michael Bowling Jr
    Systems Tested  : Microsoft Windows 11 (Azure VM)
    PowerShell Ver. : 5.1

.USAGE
    Run as Administrator on a Windows 11 system:
    PS C:\> .\WN11-CC-000210.ps1
#>

# STIG Remediation: Enable Microsoft Defender SmartScreen for Explorer
# Registry 1 - HKLM\SOFTWARE\Policies\Microsoft\Windows\System
#   Value Name: EnableSmartScreen | Value Type: REG_DWORD | Value: 1
# Registry 2 - HKLM\SOFTWARE\Policies\Microsoft\Windows\System
#   Value Name: ShellSmartScreenLevel | Value Type: REG_SZ | Value: Block

$regPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\System"

if (-not (Test-Path $regPath)) {
    New-Item -Path $regPath -Force | Out-Null
}

# Enable SmartScreen
Set-ItemProperty -Path $regPath -Name "EnableSmartScreen" -Value 1 -Type DWord

# Set SmartScreen level to Block (warn and prevent bypass)
Set-ItemProperty -Path $regPath -Name "ShellSmartScreenLevel" -Value "Block" -Type String

# Verify
$smartScreenEnabled = (Get-ItemProperty -Path $regPath -Name "EnableSmartScreen").EnableSmartScreen
$smartScreenLevel = (Get-ItemProperty -Path $regPath -Name "ShellSmartScreenLevel").ShellSmartScreenLevel

if ($smartScreenEnabled -eq 1 -and $smartScreenLevel -eq "Block") {
    Write-Host "[PASS] WN11-CC-000210: Defender SmartScreen is enabled with 'Block' level." -ForegroundColor Green
} else {
    Write-Host "[FAIL] WN11-CC-000210: Defender SmartScreen is NOT configured correctly." -ForegroundColor Red
    Write-Host "  EnableSmartScreen = $smartScreenEnabled (expected 1)" -ForegroundColor Yellow
    Write-Host "  ShellSmartScreenLevel = $smartScreenLevel (expected Block)" -ForegroundColor Yellow
}
